# Full Project Code: svdriveguard

_Generated on 2025-08-16T15:58:53.942745_

This file concatenates text-based source files from the project for quick viewing / copy-paste. Large/binary files and vendor/build directories were omitted from the concatenation to keep it readable. You still have the full extracted project in the folder.

---

## driveguard.html

```
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DriveGuard Assist - Complete Project</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
        .hidden {
            display: none;
        }
    </style>
</head>
<body class="bg-gray-50 text-gray-800">

    <!-- App Mode Switcher -->
    <div id="mode-switcher" class="min-h-screen flex flex-col justify-center items-center p-4">
        <div class="text-center">
            <h1 class="text-5xl font-extrabold text-blue-600 mb-4">DriveGuard Assist</h1>
            <p class="text-xl text-gray-600 mb-10">The complete solution for roadside assistance.</p>
            <div class="space-y-4 sm:space-y-0 sm:space-x-4">
                <button id="show-user-app-btn" class="bg-blue-600 text-white py-3 px-8 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-transform transform hover:scale-105">Launch User App</button>
                <button id="show-admin-app-btn" class="bg-gray-700 text-white py-3 px-8 rounded-lg text-lg font-semibold hover:bg-gray-800 transition-transform transform hover:scale-105">Open Admin Panel</button>
                <button id="show-agent-app-btn" class="bg-green-600 text-white py-3 px-8 rounded-lg text-lg font-semibold hover:bg-green-700 transition-transform transform hover:scale-105">Agent Portal</button>
            </div>
        </div>
    </div>

    <!-- ###################################################################################### -->
    <!-- ############################ USER APPLICATION ######################################## -->
    <!-- ###################################################################################### -->
    <div id="user-app-container" class="hidden">
        <header class="bg-white shadow-sm sticky top-0 z-50">
            <div class="container mx-auto p-4 flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <h1 class="text-3xl font-bold text-blue-600">DriveGuard</h1>
                    <button id="back-to-switcher-user" class="text-sm text-gray-500 hover:underline pt-1">&larr; Switch Mode</button>
                </div>
                <div id="auth-links">
                    <button id="show-login-btn" class="text-blue-600 font-semibold hover:underline">Login</button>
                    <button id="show-register-btn" class="ml-4 bg-blue-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-blue-700">Register</button>
                </div>
                <div id="user-info" class="hidden items-center">
                     <span id="user-email" class="mr-4 font-medium text-gray-700"></span>
                     <button id="logout-btn" class="bg-red-500 text-white py-2 px-4 rounded-lg hover:bg-red-600">Logout</button>
                </div>
            </header>

            <main id="user-content-area">
                <!-- User Landing Page (Not Logged In) -->
                <section id="user-landing-view">
                    <!-- Hero Section -->
                    <div class="bg-blue-50 text-center py-20 px-4">
                        <h2 class="text-4xl md:text-5xl font-extrabold text-gray-800">Peace of Mind on Every Journey</h2>
                        <p class="text-lg text-gray-600 mt-4 max-w-2xl mx-auto">Instant access to reliable roadside assistance. Get back on the road safely and quickly.</p>
                        <button id="get-started-btn" class="mt-8 bg-blue-600 text-white py-3 px-8 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-transform transform hover:scale-105">Get Started</button>
                    </div>

                    <!-- How It Works -->
                    <section id="how-it-works" class="py-16 bg-white">
                        <div class="container mx-auto px-4 text-center">
                            <h3 class="text-3xl font-bold mb-2">How It Works</h3>
                            <p class="text-gray-500 mb-12">Three simple steps to get help.</p>
                            <div class="grid md:grid-cols-3 gap-8">
                                <div class="p-6"><div class="flex items-center justify-center h-16 w-16 rounded-full bg-blue-100 text-blue-600 text-2xl font-bold mx-auto mb-4">1</div><h4 class="text-xl font-semibold mb-2">Request Service</h4><p>Select the service you need directly from the app. No phone call required.</p></div>
                                <div class="p-6"><div class="flex items-center justify-center h-16 w-16 rounded-full bg-blue-100 text-blue-600 text-2xl font-bold mx-auto mb-4">2</div><h4 class="text-xl font-semibold mb-2">Track Your Pro</h4><p>Watch your technician's arrival in real-time on the map.</p></div>
                                <div class="p-6"><div class="flex items-center justify-center h-16 w-16 rounded-full bg-blue-100 text-blue-600 text-2xl font-bold mx-auto mb-4">3</div><h4 class="text-xl font-semibold mb-2">Get Back on the Road</h4><p>Our certified professionals will get you moving again quickly and safely.</p></div>
                            </div>
                        </div>
                    </section>

                    <!-- Why Choose Us -->
                    <section id="why-choose-us" class="py-16 bg-gray-50">
                        <div class="container mx-auto px-4 text-center">
                             <h3 class="text-3xl font-bold mb-12">Why Choose DriveGuard?</h3>
                             <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                                <div class="bg-white p-6 rounded-lg shadow-sm text-center">
                                    <svg class="w-12 h-12 text-blue-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                    <h4 class="font-semibold text-lg">24/7 Support</h4>
                                </div>
                                <div class="bg-white p-6 rounded-lg shadow-sm text-center">
                                    <svg class="w-12 h-12 text-blue-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                                    <h4 class="font-semibold text-lg">Fast Response</h4>
                                </div>
                                <div class="bg-white p-6 rounded-lg shadow-sm text-center">
                                    <svg class="w-12 h-12 text-blue-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                    <h4 class="font-semibold text-lg">Trusted Pros</h4>
                                </div>
                                <div class="bg-white p-6 rounded-lg shadow-sm text-center">
                                    <svg class="w-12 h-12 text-blue-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                                    <h4 class="font-semibold text-lg">Clear Pricing</h4>
                                </div>
                             </div>
                        </div>
                    </section>
                </section>

                <!-- User Login View -->
                <section id="login-view" class="hidden bg-white p-8 rounded-lg shadow-md max-w-md mx-auto my-16">
                    <h2 class="text-2xl font-bold mb-6 text-center">Login to Your Account</h2>
                    <form id="login-form">
                        <div class="mb-4"><label for="login-email" class="block text-gray-700 mb-2">Email</label><input type="email" id="login-email" class="w-full p-3 border rounded-lg" required value="user@example.com"></div>
                        <div class="mb-6"><label for="login-password" class="block text-gray-700 mb-2">Password</label><input type="password" id="login-password" class="w-full p-3 border rounded-lg" required value="password123"></div>
                        <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700">Login</button>
                    </form>
                    <p id="login-error" class="text-red-500 text-center mt-4"></p>
                </section>

                <!-- User Register View -->
                <section id="register-view" class="hidden bg-white p-8 rounded-lg shadow-md max-w-lg mx-auto my-16">
                    <h2 class="text-2xl font-bold mb-6 text-center">Create an Account</h2>
                    <form id="register-form">
                        <div class="grid md:grid-cols-2 gap-4 mb-4">
                            <div><label for="register-firstname" class="block text-gray-700 mb-2">First Name</label><input type="text" id="register-firstname" class="w-full p-3 border rounded-lg" required></div>
                            <div><label for="register-lastname" class="block text-gray-700 mb-2">Last Name</label><input type="text" id="register-lastname" class="w-full p-3 border rounded-lg" required></div>
                        </div>
                        <div class="mb-4"><label for="register-email" class="block text-gray-700 mb-2">Email</label><input type="email" id="register-email" class="w-full p-3 border rounded-lg" required></div>
                        <div class="mb-4"><label for="register-phone" class="block text-gray-700 mb-2">Phone Number</label><input type="tel" id="register-phone" class="w-full p-3 border rounded-lg"></div>
                        <div class="mb-6"><label for="register-password" class="block text-gray-700 mb-2">Password</label><input type="password" id="register-password" class="w-full p-3 border rounded-lg" required></div>
                        <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700">Register</button>
                    </form>
                    <p id="register-error" class="text-red-500 text-center mt-4"></p><p id="register-success" class="text-green-500 text-center mt-4"></p>
                </section>

                <!-- User Dashboard View -->
                <section id="dashboard-view" class="hidden container mx-auto p-4">
                    <div class="bg-white p-8 rounded-lg shadow-md mb-8">
                        <h2 class="text-3xl font-bold mb-2">Request Assistance</h2>
                        <p class="text-gray-600 mb-8">Select a service below. We'll use your current location.</p>
                        <div id="services-grid" class="grid md:grid-cols-2 lg:grid-cols-3 gap-6"></div>
                        <p id="request-success" class="text-green-500 text-center mt-6 font-medium"></p><p id="request-error" class="text-red-500 text-center mt-6 font-medium"></p>
                    </div>
                    <div class="bg-white p-8 rounded-lg shadow-md">
                        <h2 class="text-3xl font-bold mb-6">Your Service History</h2>
                        <div id="requests-history" class="space-y-4"></div>
                    </div>
                </section>
            </main>
            <footer class="bg-gray-800 text-white mt-16">
                <div class="container mx-auto p-8 text-center">
                    <p>&copy; 2025 DriveGuard Assist. All rights reserved.</p>
                </div>
            </footer>
        </div>
    </div>

    <!-- ###################################################################################### -->
    <!-- ############################# ADMIN PANEL ############################################ -->
    <!-- ###################################################################################### -->
    <div id="admin-app-container" class="hidden">
        <section id="admin-login-view" class="min-h-screen flex justify-center items-center">
            <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
                 <button id="back-to-switcher-admin-login" class="text-sm text-gray-500 hover:underline mb-4">&larr; Switch Mode</button>
                <h1 class="text-3xl font-bold text-center text-blue-600 mb-2">DriveGuard Admin</h1>
                <p class="text-center text-gray-500 mb-8">Please login to continue</p>
                <form id="admin-login-form">
                    <div class="mb-4"><label for="admin-email" class="block text-gray-700 mb-2">Email</label><input type="email" id="admin-email" class="w-full p-3 border rounded-lg" required value="admin@driveguard.com"></div>
                    <div class="mb-6"><label for="admin-password" class="block text-gray-700 mb-2">Password</label><input type="password" id="admin-password" class="w-full p-3 border rounded-lg" required value="adminpass"></div>
                    <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700">Login</button>
                </form>
                <p id="admin-login-error" class="text-red-500 text-center mt-4"></p>
            </div>
        </section>

        <section id="admin-dashboard-view" class="hidden">
            <header class="bg-white shadow-sm sticky top-0 z-50">
                <div class="container mx-auto p-4 flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-blue-600">Admin Dashboard</h1>
                    <div><span id="admin-user-email" class="mr-4 font-medium"></span><button id="admin-logout-btn" class="bg-red-500 text-white py-2 px-4 rounded-lg hover:bg-red-600">Logout</button></div>
                </div>
            </header>
            <main class="container mx-auto p-4 mt-6">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <div class="bg-white p-6 rounded-lg shadow"><h3 class="text-gray-500 text-sm font-medium">Total Requests</h3><p id="stats-total-requests" class="text-3xl font-bold">0</p></div>
                    <div class="bg-white p-6 rounded-lg shadow"><h3 class="text-gray-500 text-sm font-medium">Pending Requests</h3><p id="stats-pending-requests" class="text-3xl font-bold text-yellow-500">0</p></div>
                    <div class="bg-white p-6 rounded-lg shadow"><h3 class="text-gray-500 text-sm font-medium">Completed Requests</h3><p id="stats-completed-requests" class="text-3xl font-bold text-green-500">0</p></div>
                    <div class="bg-white p-6 rounded-lg shadow"><h3 class="text-gray-500 text-sm font-medium">Total Users</h3><p id="stats-total-users" class="text-3xl font-bold">0</p></div>
                </div>
                <div class="bg-white p-8 rounded-lg shadow-md mb-8">
                    <h2 class="text-2xl font-bold mb-6">Live Service Requests</h2>
                    <div class="overflow-x-auto"><table class="min-w-full bg-white">
                        <thead class="bg-gray-50"><tr><th class="text-left py-3 px-4 font-semibold text-sm">Request ID</th><th class="text-left py-3 px-4 font-semibold text-sm">User Email</th><th class="text-left py-3 px-4 font-semibold text-sm">Service</th><th class="text-left py-3 px-4 font-semibold text-sm">Time</th><th class="text-left py-3 px-4 font-semibold text-sm">Status</th><th class="text-left py-3 px-4 font-semibold text-sm">Assignment</th></tr></thead>
                        <tbody id="requests-table-body"></tbody></table></div>
                </div>
                <div class="bg-white p-8 rounded-lg shadow-md">
                    <h2 class="text-2xl font-bold mb-6">User Management</h2>
                    <div class="overflow-x-auto"><table class="min-w-full bg-white"><thead class="bg-gray-50"><tr><th class="text-left py-3 px-4 font-semibold text-sm">User ID</th><th class="text-left py-3 px-4 font-semibold text-sm">Name</th><th class="text-left py-3 px-4 font-semibold text-sm">Email</th><th class="text-left py-3 px-4 font-semibold text-sm">Phone</th><th class="text-left py-3 px-4 font-semibold text-sm">Joined</th></tr></thead><tbody id="users-table-body"></tbody></table></div>
                </div>
            </main>
             <footer class="bg-gray-800 text-white mt-16">
                <div class="container mx-auto p-8 text-center">
                    <p>&copy; 2025 DriveGuard Assist. All rights reserved.</p>
                </div>
            </footer>
        </section>
    </div>
    
    <!-- ###################################################################################### -->
    <!-- ############################# AGENT PORTAL ########################################### -->
    <!-- ###################################################################################### -->
    <div id="agent-app-container" class="hidden">
        <section id="agent-login-view" class="min-h-screen flex justify-center items-center">
            <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
                <button id="back-to-switcher-agent-login" class="text-sm text-gray-500 hover:underline mb-4">&larr; Switch Mode</button>
                <h1 class="text-3xl font-bold text-center text-green-600 mb-2">Agent Portal</h1>
                <p class="text-center text-gray-500 mb-8">Login to view your assigned jobs.</p>
                <form id="agent-login-form">
                    <div class="mb-4"><label for="agent-email" class="block text-gray-700 mb-2">Agent Email</label><input type="email" id="agent-email" class="w-full p-3 border rounded-lg" required value="agent1@driveguard.com"></div>
                    <div class="mb-6"><label for="agent-password" class="block text-gray-700 mb-2">Password</label><input type="password" id="agent-password" class="w-full p-3 border rounded-lg" required value="agentpass"></div>
                    <button type="submit" class="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700">Login</button>
                </form>
                <p id="agent-login-error" class="text-red-500 text-center mt-4"></p>
            </div>
        </section>

        <section id="agent-dashboard-view" class="hidden">
            <header class="bg-white shadow-sm sticky top-0 z-50">
                <div class="container mx-auto p-4 flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-green-600">Agent Dashboard</h1>
                    <div><span id="agent-user-email" class="mr-4 font-medium"></span><button id="agent-logout-btn" class="bg-red-500 text-white py-2 px-4 rounded-lg hover:bg-red-600">Logout</button></div>
                </div>
            </header>
            <main class="container mx-auto p-4 mt-6">
                <h2 class="text-3xl font-bold mb-6">My Assigned Jobs</h2>
                <div id="agent-requests-list" class="space-y-6">
                    <!-- Agent jobs will be loaded here -->
                </div>
            </main>
             <footer class="bg-gray-800 text-white mt-16">
                <div class="container mx-auto p-8 text-center">
                    <p>&copy; 2025 DriveGuard Assist. All rights reserved.</p>
                </div>
            </footer>
        </section>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', () => {

        const mockDatabase = {
            users: [
                { userId: 1, firstName: 'John', lastName: 'Doe', email: 'user@example.com', password: 'password123', phone: '123-456-7890', joined: new Date('2023-10-01T10:00:00Z') },
                { userId: 2, firstName: 'Jane', lastName: 'Smith', email: 'jane.smith@example.com', password: 'password456', phone: '987-654-3210', joined: new Date('2023-11-15T14:30:00Z') },
            ],
            agents: [
                { agentId: 1, name: 'Mike Wheeler', email: 'agent1@driveguard.com', password: 'agentpass' },
                { agentId: 2, name: 'Sarah Connor', email: 'agent2@driveguard.com', password: 'agentpass' }
            ],
            requests: [
                { requestId: 101, userId: 1, serviceName: 'Fuel Delivery', time: new Date(Date.now() - 3600000), status: 'pending', agentId: null },
                { requestId: 102, userId: 2, serviceName: 'Emergency Towing', time: new Date(Date.now() - 7200000), status: 'in_progress', agentId: 1 },
                { requestId: 103, userId: 1, serviceName: 'Battery Jump-Start', time: new Date(Date.now() - 86400000), status: 'completed', agentId: 2 },
            ],
            services: [
                { serviceId: 1, serviceName: 'Run-Flat Tire Assistance', description: 'Assistance for vehicles with run-flat tires.', icon: `<svg class="w-10 h-10 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>` },
                { serviceId: 2, serviceName: 'Emergency Towing', description: 'Towing service for vehicles that are not drivable.', icon: `<svg class="w-10 h-10 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10h10m-3-10l4 4m0 0l-4 4m4-4H7"></path></svg>` },
                { serviceId: 3, serviceName: 'Fuel Delivery', description: 'Delivery of fuel for vehicles that have run out.', icon: `<svg class="w-10 h-10 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 14v-4m4 4v-4m4 4v-4M4 8h16M4 12h16M4 16h16M3 10a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4z"></path></svg>` },
                { serviceId: 4, serviceName: 'Battery Jump-Start', description: 'Service to jump-start a vehicle with a dead battery.', icon: `<svg class="w-10 h-10 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>` },
                { serviceId: 5, serviceName: 'Lockout Service', description: 'Assistance for users who are locked out.', icon: `<svg class="w-10 h-10 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>` },
                { serviceId: 6, serviceName: 'Accident Assistance', description: 'Coordination of services after an accident.', icon: `<svg class="w-10 h-10 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v4m0 4h.01"></path></svg>` }
            ],
            nextUserId: 3,
            nextRequestId: 104,
        };

        // --- GLOBAL DOM ELEMENTS ---
        const modeSwitcher = document.getElementById('mode-switcher');
        const userAppContainer = document.getElementById('user-app-container');
        const adminAppContainer = document.getElementById('admin-app-container');
        const agentAppContainer = document.getElementById('agent-app-container');
        
        // --- USER APP DOM ELEMENTS ---
        const userLandingView = document.getElementById('user-landing-view');
        const loginView = document.getElementById('login-view');
        const registerView = document.getElementById('register-view');
        const dashboardView = document.getElementById('dashboard-view');
        const authLinks = document.getElementById('auth-links');
        const userInfo = document.getElementById('user-info');
        const userEmailSpan = document.getElementById('user-email');
        const loginForm = document.getElementById('login-form');
        const registerForm = document.getElementById('register-form');
        const servicesGrid = document.getElementById('services-grid');
        const requestsHistory = document.getElementById('requests-history');
        const loginError = document.getElementById('login-error');
        const registerError = document.getElementById('register-error');
        const registerSuccess = document.getElementById('register-success');
        const requestSuccess = document.getElementById('request-success');
        const requestError = document.getElementById('request-error');

        // --- ADMIN APP DOM ELEMENTS ---
        const adminLoginView = document.getElementById('admin-login-view');
        const adminDashboardView = document.getElementById('admin-dashboard-view');
        const adminLoginForm = document.getElementById('admin-login-form');
        const adminLoginError = document.getElementById('admin-login-error');
        const adminUserEmailSpan = document.getElementById('admin-user-email');
        const requestsTableBody = document.getElementById('requests-table-body');
        const usersTableBody = document.getElementById('users-table-body');
        const statsTotalRequests = document.getElementById('stats-total-requests');
        const statsPendingRequests = document.getElementById('stats-pending-requests');
        const statsCompletedRequests = document.getElementById('stats-completed-requests');
        const statsTotalUsers = document.getElementById('stats-total-users');

        // --- AGENT APP DOM ELEMENTS ---
        const agentLoginView = document.getElementById('agent-login-view');
        const agentDashboardView = document.getElementById('agent-dashboard-view');
        const agentLoginForm = document.getElementById('agent-login-form');
        const agentLoginError = document.getElementById('agent-login-error');
        const agentUserEmailSpan = document.getElementById('agent-user-email');
        const agentRequestsList = document.getElementById('agent-requests-list');

        // --- APP STATE ---
        let currentUser = null;
        let currentAdmin = null;
        let currentAgent = null;
        
        // --- GENERAL FUNCTIONS ---
        function clearAllMessages() {
            [loginError, registerError, registerSuccess, requestSuccess, requestError, adminLoginError, agentLoginError].forEach(el => el.textContent = '');
        }

        function showMode(mode) {
            clearAllMessages();
            modeSwitcher.classList.add('hidden');
            userAppContainer.classList.add('hidden');
            adminAppContainer.classList.add('hidden');
            agentAppContainer.classList.add('hidden');

            if (mode === 'user') { userAppContainer.classList.remove('hidden'); updateUserUI(); } 
            else if (mode === 'admin') { adminAppContainer.classList.remove('hidden'); updateAdminUI(); } 
            else if (mode === 'agent') { agentAppContainer.classList.remove('hidden'); updateAgentUI(); } 
            else { modeSwitcher.classList.remove('hidden'); }
        }

        // --- USER APP LOGIC ---
        function showUserView(viewName) {
            [userLandingView, loginView, registerView, dashboardView].forEach(v => v.classList.add('hidden'));
            const viewToShow = document.getElementById(viewName);
            if(viewToShow) viewToShow.classList.remove('hidden');
        }

        function updateUserUI() {
            if (currentUser) {
                authLinks.classList.add('hidden');
                userInfo.classList.remove('hidden');
                userEmailSpan.textContent = `Welcome, ${currentUser.email}`;
                showUserView('dashboard-view');
                renderServices();
                renderRequestHistory();
            } else {
                authLinks.classList.remove('hidden');
                userInfo.classList.add('hidden');
                userEmailSpan.textContent = '';
                showUserView('user-landing-view');
            }
        }

        function renderServices() {
            servicesGrid.innerHTML = '';
            mockDatabase.services.forEach(service => {
                const serviceCard = document.createElement('div');
                serviceCard.className = 'bg-gray-50 p-6 rounded-lg border hover:shadow-lg transition-shadow cursor-pointer flex items-center space-x-4';
                serviceCard.innerHTML = `<div>${service.icon}</div><div><h3 class="font-bold text-lg">${service.serviceName}</h3><p class="text-gray-600 text-sm">${service.description}</p></div>`;
                serviceCard.onclick = () => createServiceRequest(service.serviceId);
                servicesGrid.appendChild(serviceCard);
            });
        }

        function renderRequestHistory() {
            requestsHistory.innerHTML = '';
            const userRequests = mockDatabase.requests.filter(r => r.userId === currentUser.userId).sort((a, b) => b.time - a.time);
            if (userRequests.length === 0) {
                requestsHistory.innerHTML = '<p class="text-gray-500 text-center">You have no past service requests.</p>';
                return;
            }
            userRequests.forEach(req => {
                const statusColor = { pending: 'bg-yellow-100 text-yellow-700', in_progress: 'bg-blue-100 text-blue-700', completed: 'bg-green-100 text-green-700' };
                const requestItem = document.createElement('div');
                requestItem.className = 'border p-4 rounded-lg flex justify-between items-center';
                requestItem.innerHTML = `<div><p class="font-semibold">${req.serviceName}</p><p class="text-sm text-gray-500">Requested on: ${new Date(req.time).toLocaleString()}</p></div><span class="text-sm font-medium py-1 px-3 rounded-full ${statusColor[req.status]} capitalize">${req.status.replace('_', ' ')}</span>`;
                requestsHistory.appendChild(requestItem);
            });
        }

        function createServiceRequest(serviceId) {
            clearAllMessages();
            const service = mockDatabase.services.find(s => s.serviceId === serviceId);
            mockDatabase.requests.push({ requestId: mockDatabase.nextRequestId++, userId: currentUser.userId, serviceName: service.serviceName, time: new Date(), status: 'pending', agentId: null });
            requestSuccess.textContent = `Request for "${service.serviceName}" sent successfully!`;
            setTimeout(() => requestSuccess.textContent = '', 5000);
            renderRequestHistory();
        }

        // --- ADMIN APP LOGIC ---
        function showAdminView(view) {
            adminLoginView.classList.add('hidden');
            adminDashboardView.classList.add('hidden');
            if (view === 'login') adminLoginView.classList.remove('hidden');
            if (view === 'dashboard') adminDashboardView.classList.remove('hidden');
        }

        function updateAdminUI() {
            if (currentAdmin) {
                adminUserEmailSpan.textContent = `Admin: ${currentAdmin.email}`;
                showAdminView('dashboard');
                renderAdminDashboard();
            } else {
                showAdminView('login');
            }
        }

        function renderAdminDashboard() {
            renderRequestsTable();
            renderUsersTable();
            updateStats();
        }

        function updateStats() {
            statsTotalRequests.textContent = mockDatabase.requests.length;
            statsPendingRequests.textContent = mockDatabase.requests.filter(r => r.status === 'pending').length;
            statsCompletedRequests.textContent = mockDatabase.requests.filter(r => r.status === 'completed').length;
            statsTotalUsers.textContent = mockDatabase.users.length;
        }

        function renderRequestsTable() {
            requestsTableBody.innerHTML = '';
            mockDatabase.requests.sort((a, b) => b.time - a.time).forEach(req => {
                const user = mockDatabase.users.find(u => u.userId === req.userId);
                const row = document.createElement('tr');
                row.className = 'border-b hover:bg-gray-50';
                const statusColor = { pending: 'text-yellow-600', in_progress: 'text-blue-600', completed: 'text-green-600' };
                
                let assignmentHtml = '';
                if (req.status === 'pending') {
                    const options = mockDatabase.agents.map(agent => `<option value="${agent.agentId}">${agent.name}</option>`).join('');
                    assignmentHtml = `<select onchange="window.assignRequestToAgent(${req.requestId}, this.value)" class="p-1 border rounded-md"><option value="">Assign Agent</option>${options}</select>`;
                } else {
                    const assignedAgent = mockDatabase.agents.find(a => a.agentId === req.agentId);
                    assignmentHtml = assignedAgent ? assignedAgent.name : 'N/A';
                }

                row.innerHTML = `
                    <td class="py-3 px-4">${req.requestId}</td>
                    <td class="py-3 px-4">${user ? user.email : 'N/A'}</td>
                    <td class="py-3 px-4">${req.serviceName}</td>
                    <td class="py-3 px-4">${req.time.toLocaleString()}</td>
                    <td class="py-3 px-4 font-medium capitalize ${statusColor[req.status] || ''}">${req.status.replace('_', ' ')}</td>
                    <td class="py-3 px-4">${assignmentHtml}</td>`;
                requestsTableBody.appendChild(row);
            });
        }

        function renderUsersTable() {
            usersTableBody.innerHTML = '';
            mockDatabase.users.forEach(user => {
                const row = document.createElement('tr');
                row.className = 'border-b hover:bg-gray-50';
                row.innerHTML = `<td class="py-3 px-4">${user.userId}</td><td class="py-3 px-4">${user.firstName} ${user.lastName}</td><td class="py-3 px-4">${user.email}</td><td class="py-3 px-4">${user.phone}</td><td class="py-3 px-4">${user.joined.toLocaleDateString()}</td>`;
                usersTableBody.appendChild(row);
            });
        }
        
        window.assignRequestToAgent = (requestId, agentId) => {
            const request = mockDatabase.requests.find(r => r.requestId == requestId);
            if (request && agentId) {
                request.agentId = parseInt(agentId);
                request.status = 'in_progress';
                renderAdminDashboard();
            }
        }

        // --- AGENT APP LOGIC ---
        function showAgentView(view) {
            agentLoginView.classList.add('hidden');
            agentDashboardView.classList.add('hidden');
            if (view === 'login') agentLoginView.classList.remove('hidden');
            if (view === 'dashboard') agentDashboardView.classList.remove('hidden');
        }

        function updateAgentUI() {
            if (currentAgent) {
                agentUserEmailSpan.textContent = `Agent: ${currentAgent.name}`;
                showAgentView('dashboard');
                renderAgentDashboard();
            } else {
                showAgentView('login');
            }
        }

        function renderAgentDashboard() {
            agentRequestsList.innerHTML = '';
            const agentRequests = mockDatabase.requests.filter(r => r.agentId === currentAgent.agentId && r.status !== 'completed').sort((a,b) => b.time - a.time);

            if (agentRequests.length === 0) {
                agentRequestsList.innerHTML = '<p class="text-gray-500 text-center">You have no active jobs.</p>';
                return;
            }

            agentRequests.forEach(req => {
                const user = mockDatabase.users.find(u => u.userId === req.userId);
                const card = document.createElement('div');
                card.className = 'bg-white p-6 rounded-lg shadow-md';
                card.innerHTML = `
                    <div class="flex justify-between items-start">
                        <div>
                            <h3 class="text-xl font-bold">${req.serviceName}</h3>
                            <p class="text-gray-600">For: ${user ? user.firstName + ' ' + user.lastName : 'N/A'} (${user ? user.phone : ''})</p>
                            <p class="text-sm text-gray-500">Requested: ${req.time.toLocaleString()}</p>
                        </div>
                        <span class="text-sm font-medium py-1 px-3 rounded-full bg-blue-100 text-blue-700 capitalize">${req.status.replace('_', ' ')}</span>
                    </div>
                    <div class="mt-4 pt-4 border-t">
                        <button class="bg-green-500 text-white py-2 px-4 rounded-lg hover:bg-green-600" onclick="window.updateAgentRequestStatus(${req.requestId}, 'completed')">Mark as Complete</button>
                    </div>
                `;
                agentRequestsList.appendChild(card);
            });
        }

        window.updateAgentRequestStatus = (requestId, newStatus) => {
            const request = mockDatabase.requests.find(r => r.requestId === requestId);
            if (request && request.agentId === currentAgent.agentId) {
                request.status = newStatus;
                renderAgentDashboard();
            }
        };

        // --- EVENT LISTENERS ---
        document.getElementById('show-user-app-btn').addEventListener('click', () => showMode('user'));
        document.getElementById('show-admin-app-btn').addEventListener('click', () => showMode('admin'));
        document.getElementById('show-agent-app-btn').addEventListener('click', () => showMode('agent'));
        
        [document.getElementById('back-to-switcher-user'), document.getElementById('back-to-switcher-admin-login'), document.getElementById('back-to-switcher-agent-login')].forEach(btn => {
            btn.addEventListener('click', () => showMode('main'));
        });

        document.getElementById('show-login-btn').addEventListener('click', () => showUserView('login-view'));
        document.getElementById('get-started-btn').addEventListener('click', () => showUserView('register-view'));
        document.getElementById('show-register-btn').addEventListener('click', () => showUserView('register-view'));
        
        document.getElementById('logout-btn').addEventListener('click', () => { currentUser = null; updateUserUI(); });
        document.getElementById('admin-logout-btn').addEventListener('click', () => { currentAdmin = null; updateAdminUI(); });
        document.getElementById('agent-logout-btn').addEventListener('click', () => { currentAgent = null; updateAgentUI(); });

        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            clearAllMessages();
            const email = document.getElementById('login-email').value;
            const password = document.getElementById('login-password').value;
            const user = mockDatabase.users.find(u => u.email === email && u.password === password);
            if (user) { currentUser = user; updateUserUI(); loginForm.reset(); } 
            else { loginError.textContent = 'Invalid credentials.'; }
        });

        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            clearAllMessages();
            const email = document.getElementById('register-email').value;
            if (mockDatabase.users.some(u => u.email === email)) {
                registerError.textContent = 'A user with this email already exists.';
                return;
            }
            mockDatabase.users.push({
                userId: mockDatabase.nextUserId++,
                firstName: document.getElementById('register-firstname').value,
                lastName: document.getElementById('register-lastname').value,
                email: email,
                password: document.getElementById('register-password').value,
                phone: document.getElementById('register-phone').value,
                joined: new Date()
            });
            registerSuccess.textContent = 'Registration successful! Please login.';
            registerForm.reset();
            setTimeout(() => showUserView('login-view'), 2000);
        });

        adminLoginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            clearAllMessages();
            const email = document.getElementById('admin-email').value;
            const password = document.getElementById('admin-password').value;
            if (email === 'admin@driveguard.com' && password === 'adminpass') {
                currentAdmin = { email: email, role: 'admin' };
                updateAdminUI();
            } else {
                adminLoginError.textContent = 'Invalid admin credentials.';
            }
        });

        agentLoginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            clearAllMessages();
            const email = document.getElementById('agent-email').value;
            const password = document.getElementById('agent-password').value;
            const agent = mockDatabase.agents.find(a => a.email === email && a.password === password);
            if (agent) {
                currentAgent = agent;
                updateAgentUI();
            } else {
                agentLoginError.textContent = 'Invalid agent credentials.';
            }
        });
    });
    </script>
</body>
</html>

```

---

